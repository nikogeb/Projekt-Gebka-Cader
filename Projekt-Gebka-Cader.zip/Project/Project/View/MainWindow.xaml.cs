﻿using Project.Database.Entities;
using Project.Database.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Project
{
    public partial class MainWindow : Window
    {
        private List<Person> personList = new List<Person>();
        private List<Active> activeList = new List<Active>();
        private List<Consistency> consistencyList = new List<Consistency>();
        private List<Product> productList = new List<Product>();
        private bool personClickRefresh = false;
        private bool personClickselect = false;
        private bool productClickRefresh = false;
        private bool productClickselect = false;
        private List<string> skin_type = new List<string>();
        private List<string> gender = new List<string>();
        public MainWindow()
        {
            InitializeComponent();
            skin_type.Add("normalna");
            skin_type.Add("sucha");
            skin_type.Add("tlusta");
            skin_type.Add("dojrzala");
            skin_type.Add("problematyczna");
            skin_type.Add("naczynkowa");
            skin_type.Add("mieszana");
            gender.Add("mezczyzna");
            gender.Add("kobieta");
            gender.Add("inne");
        }
        #region View
        private void open(object sender, ContextMenuEventArgs e)
        {
        }
        private void init(object sender, EventArgs e)  // add select person table 
        {
            pearsonList.Items.Clear();
            consistencyListView.Items.Clear();
            productListView.Items.Clear();
            activeSubstanceListView.Items.Clear();
            personList = RepositoryPerson.selectPerson();
            foreach (var o in personList)
            {
                pearsonList.Items.Add(o.ToString());
            }
            pearsonList.SelectedIndex = 0;
            consistencyListView.SelectedIndex = 0;
            productListView.SelectedIndex = 0;
            activeSubstanceListView.SelectedIndex = 0;
        }
        private void ViewButtonClick(object sender, RoutedEventArgs e)
        {
            pearsonList.Items.Clear();
            consistencyListView.Items.Clear();
            productListView.Items.Clear();
            activeSubstanceListView.Items.Clear();
            personList = RepositoryPerson.selectPerson();
            foreach (var o in personList)
            {
                pearsonList.Items.Add(o.ToString());
            }
            pearsonList.SelectedIndex = 0;
            consistencyListView.SelectedIndex = 0;
            productListView.SelectedIndex = 0;
            activeSubstanceListView.SelectedIndex = 0;
        }

        private void pearsonSelectionChange(object sender, SelectionChangedEventArgs e)
        {
            consistencyListView.Items.Clear();
            productListView.Items.Clear();
            activeSubstanceListView.Items.Clear();
            if (pearsonList.SelectedItem != null) {
                int indexPerson = pearsonList.SelectedIndex;
                consistencyList = RepositoryConsistency.selectConsistencyByPerson(personList[indexPerson]);
                foreach (var o in consistencyList)
                {
                    consistencyListView.Items.Add(o.ToString());
                }
            }
            consistencyListView.SelectedIndex = 0;
            productListView.SelectedIndex = 0;
            activeSubstanceListView.SelectedIndex = 0;
        }
        private void consistencySelectionChanged(object sender, SelectionChangedEventArgs e) // add selset products table where id_product == id_consistence 
        {
            productListView.Items.Clear();
            activeSubstanceListView.Items.Clear();
            if (consistencyListView.SelectedItem != null)
            {
                int indexConsistency = consistencyListView.SelectedIndex;
                if (consistencyList.Count >= 0) {
                    productList = ReposityryProduct.selectProductByConsistency(consistencyList[indexConsistency]);
                    foreach (var o in productList)
                    {
                        productListView.Items.Add(o.ToString());
                    }
                }
            }
            productListView.SelectedIndex = 0;
            activeSubstanceListView.SelectedIndex = 0;
        }
        private void productSelectionChanged(object sender, SelectionChangedEventArgs e) // add selset actiw substance table where id_product == id_activ substance 
        {
            activeSubstanceListView.Items.Clear();
            if (productListView.SelectedItem != null)
            {
                if (productList.Count >= 0) {
                    int indexProduct = productListView.SelectedIndex;
                    activeList = RepositoryActive.selectActiveByProduct(productList[indexProduct]);
                    foreach (var o in activeList)
                    {
                        activeSubstanceListView.Items.Add(o.ToString());
                    }
                }
            }
            
        }
        #endregion
        #region Edit consistency
        private void ConsisistencyInit(object sender, EventArgs e)
        {
            
        }

        private void consistencyaddbutton(object sender, RoutedEventArgs e)
        {
            RepositoryConsistency.addConsistency(new Database.Entities.Consistency(consistencyTextBox.Text));
            consistencyListView1.Items.Clear();
            consistencyTextBox.Text = "default";
            consistencyList = RepositoryConsistency.selectConsistency();
            foreach (var o in consistencyList)
            {
                consistencyListView1.Items.Add(o.ToString());
            }
        }

        private void consistencyRefreshButton(object sender, RoutedEventArgs e)
        {
            consistencyListView1.Items.Clear();
            consistencyTextBox.Text = "default";
            consistencyList = RepositoryConsistency.selectConsistency();
            foreach (var o in consistencyList)
            {
                consistencyListView1.Items.Add(o.ToString());
            }
        }

        private void consistencyEditButton(object sender, RoutedEventArgs e)
        {
            if (consistencyListView1.SelectedIndex >= 0)
            {
                consistencyList[consistencyListView1.SelectedIndex].consistency = consistencyTextBox.Text;
                RepositoryConsistency.updateConsistency(consistencyList[consistencyListView1.SelectedIndex]);
                consistencyListView1.Items.Clear();
                consistencyTextBox.Text = "default";
                consistencyList = RepositoryConsistency.selectConsistency();
                foreach (var o in consistencyList)
                {
                    consistencyListView1.Items.Add(o.ToString());
                }
            }
        }

        private void consistencySelected(object sender, SelectionChangedEventArgs e)
        {
                if (consistencyListView1.SelectedIndex >= 0)
                {
                    consistencyList = RepositoryConsistency.selectConsistency();
                    consistencyTextBox.Text = consistencyList[consistencyListView1.SelectedIndex].consistency;
                }
        }
        #endregion
        #region Edit substance
        private void substanceRefreshButton(object sender, RoutedEventArgs e)
        {
            substanceListView.Items.Clear();
            substanceTextBox.Text = "default";
            substanceCombo.Items.Clear();
            substanceCombo.Items.Add("tak");
            substanceCombo.Items.Add("nie");
            substanceCombo.SelectedIndex = 0;
            substanceTextBoxSubUs.Text = "default";
            activeList = RepositoryActive.selectActive();
            foreach (var o in activeList)
            {
                substanceListView.Items.Add(o.ToString());
            }
        }

        private void substanceSelected(object sender, SelectionChangedEventArgs e)
        {
                if (substanceListView.SelectedIndex >= 0)
                {
                    activeList = RepositoryActive.selectActive();
                    substanceTextBox.Text = activeList[substanceListView.SelectedIndex].substance;
                    substanceCombo.SelectedItem = activeList[substanceListView.SelectedIndex].irritation;
                    substanceTextBoxSubUs.Text = activeList[substanceListView.SelectedIndex].substance_use;
                }
        }

        private void substanceaddbutton(object sender, RoutedEventArgs e)
        {
            RepositoryActive.addActive(new Database.Entities.Active(substanceTextBox.Text, substanceTextBoxSubUs.Text, substanceCombo.Text));
            substanceListView.Items.Clear();
            substanceTextBox.Text = "default";
            substanceCombo.SelectedIndex = 0;
            substanceTextBoxSubUs.Text = "default";
            activeList = RepositoryActive.selectActive();
            foreach (var o in activeList)
            {
                substanceListView.Items.Add(o.ToString());
            }
        }

        private void substanceEditButton(object sender, RoutedEventArgs e)
        {
            if (substanceListView.SelectedIndex >= 0)
            {
                activeList = RepositoryActive.selectActive();
                activeList[substanceListView.SelectedIndex].substance = substanceTextBox.Text;
                activeList[substanceListView.SelectedIndex].irritation = substanceCombo.SelectedItem.ToString();
                activeList[substanceListView.SelectedIndex].substance_use = substanceTextBoxSubUs.Text;
                RepositoryActive.updateActive(activeList[substanceListView.SelectedIndex]);
                substanceListView.Items.Clear();
                substanceTextBox.Text = "default";
                substanceCombo.SelectedIndex = 0;
                substanceTextBoxSubUs.Text = "default";
                activeList = RepositoryActive.selectActive();
                foreach (var o in activeList)
                {
                    substanceListView.Items.Add(o.ToString());
                }
            }
        }

        private void substanceInit(object sender, EventArgs e)
        {

        }
        #endregion
        #region Edit person
        private void personAddButton(object sender, RoutedEventArgs e)
        {
            if (personClickRefresh)
            {
                List<String> list = new List<String>();
                foreach (string test in personConsistencyListView.SelectedItems)
                {
                    list.Add(test);
                }
                RepositoryPerson.addPerson(new Person(personNameTextBox.Text, personGenderComboBox.SelectedItem.ToString(), sbyte.Parse(personAgeComboBox.SelectedItem.ToString()), personSkinTypeComboBox.SelectedItem.ToString()), list);
                personAgeComboBox.Items.Clear();
                for (int i = 1; i <= 120; i++)
                {
                    personAgeComboBox.Items.Add((i.ToString()));
                }
                personClickselect = false;
                personAgeComboBox.SelectedIndex = 0;
                personGenderComboBox.Items.Clear();
                foreach (string s in gender) { personGenderComboBox.Items.Add(s); }
                personGenderComboBox.SelectedIndex = 0;
                personSkinTypeComboBox.Items.Clear();
                foreach (string s in skin_type) { personSkinTypeComboBox.Items.Add(s); }
                personSkinTypeComboBox.SelectedIndex = 0;
                personNameTextBox.Text = "default";
                personPersonListView.Items.Clear();
                personConsistencyListView.Items.Clear();
                personList = RepositoryPerson.selectPerson();
                foreach (var o in personList)
                {
                    personPersonListView.Items.Add(o.ToString());
                }
                consistencyList = RepositoryConsistency.selectConsistency();
                foreach (var o in consistencyList)
                {
                    personConsistencyListView.Items.Add(o.ToString());

                }
            }
        }

        private void personDeleteButton(object sender, RoutedEventArgs e)
        {
            if (personClickselect)
            {
                    RepositoryPerson.deletePerson(personList[personPersonListView.SelectedIndex]);
                    personClickRefresh = true;
                    personClickselect = false;
                    personAgeComboBox.Items.Clear();
                    for (int i = 1; i <= 120; i++)
                    {
                        personAgeComboBox.Items.Add((i.ToString()));
                    }
                    personAgeComboBox.SelectedIndex = 0;
                    personGenderComboBox.Items.Clear();
                    foreach (string s in gender) { personGenderComboBox.Items.Add(s); }
                    personGenderComboBox.SelectedIndex = 0;
                    personSkinTypeComboBox.Items.Clear();
                    foreach (string s in skin_type) { personSkinTypeComboBox.Items.Add(s); }
                    personSkinTypeComboBox.SelectedIndex = 0;
                    personNameTextBox.Text = "default";
                    personConsistencyListView.Items.Clear();
                    personPersonListView.Items.Clear();
                    personList = RepositoryPerson.selectPerson();
                    foreach (var o in personList)
                    {
                        personPersonListView.Items.Add(o.ToString());
                    }
                    consistencyList = RepositoryConsistency.selectConsistency();
                    foreach (var o in consistencyList)
                    {
                        personConsistencyListView.Items.Add(o.ToString());

                    }
            }
        }

        private void personEditButton(object sender, RoutedEventArgs e)
        {
            if (personClickselect)
            {
                    personList = RepositoryPerson.selectPerson();
                    personList[personPersonListView.SelectedIndex].age = sbyte.Parse(personAgeComboBox.SelectedItem.ToString());
                    personList[personPersonListView.SelectedIndex].gender = personGenderComboBox.SelectedItem.ToString();
                    personList[personPersonListView.SelectedIndex].skinType = personSkinTypeComboBox.SelectedItem.ToString();
                    personList[personPersonListView.SelectedIndex].name = personNameTextBox.Text;
                    List<String> list = new List<String>();
                    foreach (string test in personConsistencyListView.SelectedItems)
                    {
                        list.Add(test);
                    }
                    RepositoryPerson.updatePerson(personList[personPersonListView.SelectedIndex], list);
                    personClickRefresh = true;
                    personClickselect = false;
                    personAgeComboBox.Items.Clear();
                    for (int i = 1; i <= 120; i++)
                    {
                        personAgeComboBox.Items.Add((i.ToString()));
                    }
                    personAgeComboBox.SelectedIndex = 0;
                    personGenderComboBox.Items.Clear();
                    foreach (string s in gender) { personGenderComboBox.Items.Add(s); }
                    personGenderComboBox.SelectedIndex = 0;
                    personSkinTypeComboBox.Items.Clear(); 
                    foreach (string s in skin_type) { personSkinTypeComboBox.Items.Add(s); }
                    personSkinTypeComboBox.SelectedIndex = 0;
                    personNameTextBox.Text = "default";
                    personConsistencyListView.Items.Clear();
                    personPersonListView.Items.Clear();
                    personList = RepositoryPerson.selectPerson();
                    foreach (var o in personList)
                    {
                        personPersonListView.Items.Add(o.ToString());
                    }
                    consistencyList = RepositoryConsistency.selectConsistency();
                    foreach (var o in consistencyList)
                    {
                        personConsistencyListView.Items.Add(o.ToString());

                    }
            }
        }

        private void personRefreshButton(object sender, RoutedEventArgs e)
        {
            personClickRefresh = true;
            personClickselect = false;
            personAgeComboBox.Items.Clear();
            for (int i = 1; i<= 120; i++)
            {
                personAgeComboBox.Items.Add((i.ToString()));
            }
            personAgeComboBox.SelectedIndex = 0;
            personGenderComboBox.Items.Clear();
            foreach (string s in gender) { personGenderComboBox.Items.Add(s); }
            personGenderComboBox.SelectedIndex = 0;
            personSkinTypeComboBox.Items.Clear();
            foreach (string s in skin_type) { personSkinTypeComboBox.Items.Add(s); }
            personSkinTypeComboBox.SelectedIndex = 0;
            personNameTextBox.Text = "default";
            personConsistencyListView.Items.Clear();
            personPersonListView.Items.Clear();
            personList = RepositoryPerson.selectPerson();
            foreach (var o in personList)
            {
                personPersonListView.Items.Add(o.ToString());
            }
            consistencyList = RepositoryConsistency.selectConsistency();
            foreach (var o in consistencyList)
            {
                personConsistencyListView.Items.Add(o.ToString());

            }
        }
        private void personSelected(object sender, SelectionChangedEventArgs e)
        {
            if (personPersonListView.SelectedIndex >= 0)
            {
                personClickselect = true;
                personConsistencyListView.Items.Clear();
                personList = RepositoryPerson.selectPerson();
                consistencyList = RepositoryConsistency.selectConsistency();
                var consistencyList2 = RepositoryConsistency.selectConsistencyByPerson(personList[personPersonListView.SelectedIndex]);
                foreach (var o in consistencyList)
                {
                    personConsistencyListView.Items.Add(o.ToString());
                   
                }
                foreach (var o2 in consistencyList2)
                {
                    personConsistencyListView.SelectedItems.Add(o2.ToString());
                }
                personAgeComboBox.SelectedItem = personList[personPersonListView.SelectedIndex].age.ToString();
                personGenderComboBox.SelectedItem = personList[personPersonListView.SelectedIndex].gender;
                personSkinTypeComboBox.SelectedItem = personList[personPersonListView.SelectedIndex].skinType;
                personNameTextBox.Text = personList[personPersonListView.SelectedIndex].name;
            }
        }
        #endregion
        #region Edit products
        private void productRefreshButton(object sender, RoutedEventArgs e)
        {
            productActiveListView.Items.Clear();
            productProductLoistview.Items.Clear();
            productClickRefresh = true;
            productClickselect = false;
            productNameTextBox.Text = "default";
            productFrequencyTextBox.Text = "default";
            productTypeTextBox.Text = "default";
            productUseTextBox.Text = "default";
            productSkinTypeComboBox.Items.Clear();
            productConsistencyComboBox.Items.Clear();
            foreach (string s in skin_type) { productSkinTypeComboBox.Items.Add(s); }
            productSkinTypeComboBox.SelectedIndex = 0;
            consistencyList = RepositoryConsistency.selectConsistency();
            foreach (var o in consistencyList)
            {
                productConsistencyComboBox.Items.Add(o.ToString());

            }
            productConsistencyComboBox.SelectedIndex = 0;
            activeList = RepositoryActive.selectActive();
            foreach (var o in activeList)
            {
                productActiveListView.Items.Add(o.ToString());
            }
            productList = ReposityryProduct.selectProduct();
            foreach (var o in productList)
            {
                productProductLoistview.Items.Add(o.ToString());
            }
        }

        private void productDeleteButton(object sender, RoutedEventArgs e)
        {
            if (productClickselect)
            {
                productClickselect = false;
                ReposityryProduct.deleteProcuct(productList[productProductLoistview.SelectedIndex]);
                productActiveListView.Items.Clear();
                productProductLoistview.Items.Clear();
                productClickRefresh = true;
                productClickselect = false;
                productNameTextBox.Text = "default";
                productFrequencyTextBox.Text = "default";
                productTypeTextBox.Text = "default";
                productUseTextBox.Text = "default";
                productSkinTypeComboBox.Items.Clear();
                productConsistencyComboBox.Items.Clear();
                foreach (string s in skin_type) { productSkinTypeComboBox.Items.Add(s); }
                productSkinTypeComboBox.SelectedIndex = 0;
                consistencyList = RepositoryConsistency.selectConsistency();
                foreach (var o in consistencyList)
                {
                    productConsistencyComboBox.Items.Add(o.ToString());

                }
                productConsistencyComboBox.SelectedIndex = 0;
                activeList = RepositoryActive.selectActive();
                foreach (var o in activeList)
                {
                    productActiveListView.Items.Add(o.ToString());
                }
                productList = ReposityryProduct.selectProduct();
                foreach (var o in productList)
                {
                    productProductLoistview.Items.Add(o.ToString());
                }
            }
        }

        private void productEditButton(object sender, RoutedEventArgs e)
        {
            if (productClickselect)
            {
                productList[productProductLoistview.SelectedIndex].name = productNameTextBox.Text;
                productList[productProductLoistview.SelectedIndex].frequency = productFrequencyTextBox.Text;
                productList[productProductLoistview.SelectedIndex].type = productTypeTextBox.Text;
                productList[productProductLoistview.SelectedIndex].use = productUseTextBox.Text;
                productList[productProductLoistview.SelectedIndex].skinType = productSkinTypeComboBox.SelectedItem.ToString();

                List<String> list = new List<String>();
                foreach (string test in productActiveListView.SelectedItems)
                {
                    list.Add(test);
                }

                List<Consistency> consistencyList = RepositoryConsistency.selectConsistency();
                foreach (Consistency conList in consistencyList)
                {
                    if (productConsistencyComboBox.SelectedItem.ToString().ToLower() == conList.ToString())
                    {
                        productList[productProductLoistview.SelectedIndex].id_consistency = sbyte.Parse(conList.id.ToString());
                    }
                }
                ReposityryProduct.updateProcuct(productList[productProductLoistview.SelectedIndex], list);
                productActiveListView.Items.Clear();
                productProductLoistview.Items.Clear();
                productClickRefresh = true;
                productClickselect = false;
                productNameTextBox.Text = "default";
                productFrequencyTextBox.Text = "default";
                productTypeTextBox.Text = "default";
                productUseTextBox.Text = "default";
                productSkinTypeComboBox.Items.Clear();
                productConsistencyComboBox.Items.Clear();
                foreach (string s in skin_type) { productSkinTypeComboBox.Items.Add(s); }
                productSkinTypeComboBox.SelectedIndex = 0;
                consistencyList = RepositoryConsistency.selectConsistency();
                foreach (var o in consistencyList)
                {
                    productConsistencyComboBox.Items.Add(o.ToString());

                }
                productConsistencyComboBox.SelectedIndex = 0;
                activeList = RepositoryActive.selectActive();
                foreach (var o in activeList)
                {
                    productActiveListView.Items.Add(o.ToString());
                }
                productList = ReposityryProduct.selectProduct();
                foreach (var o in productList)
                {
                    productProductLoistview.Items.Add(o.ToString());
                }
            }
        }

        private void productAddButton(object sender, RoutedEventArgs e)
        {
            if (productClickRefresh)
            {
                List<String> list = new List<String>();
                foreach (string test in productActiveListView.SelectedItems)
                {
                    list.Add(test);
                }

                List<Consistency> consistencyList = RepositoryConsistency.selectConsistency();
                foreach (Consistency conList in consistencyList)
                {
                        if (productConsistencyComboBox.SelectedItem.ToString().ToLower() == conList.ToString())
                        {
                            ReposityryProduct.addProcuct(new Product(productNameTextBox.Text, productTypeTextBox.Text, productUseTextBox.Text, productFrequencyTextBox.Text, productSkinTypeComboBox.SelectedItem.ToString(), sbyte.Parse(conList.id.ToString())), list);
                        }
                }
                productActiveListView.Items.Clear();
                productProductLoistview.Items.Clear();
                productClickRefresh = true;
                productClickselect = false;
                productNameTextBox.Text = "default";
                productFrequencyTextBox.Text = "default";
                productTypeTextBox.Text = "default";
                productUseTextBox.Text = "default";
                productSkinTypeComboBox.Items.Clear();
                productConsistencyComboBox.Items.Clear();
                foreach (string s in skin_type) { productSkinTypeComboBox.Items.Add(s); }
                productSkinTypeComboBox.SelectedIndex = 0;
                consistencyList = RepositoryConsistency.selectConsistency();
                foreach (var o in consistencyList)
                {
                    productConsistencyComboBox.Items.Add(o.ToString());

                }
                productConsistencyComboBox.SelectedIndex = 0;
                activeList = RepositoryActive.selectActive();
                foreach (var o in activeList)
                {
                    productActiveListView.Items.Add(o.ToString());
                }
                productList = ReposityryProduct.selectProduct();
                foreach (var o in productList)
                {
                    productProductLoistview.Items.Add(o.ToString());
                }

            }
        }

        private void productselectedProduct(object sender, SelectionChangedEventArgs e)
        {
            productActiveListView.Items.Clear();
            if (productProductLoistview.SelectedIndex >= 0) {
                productClickselect = true;
                productNameTextBox.Text = productList[productProductLoistview.SelectedIndex].name;
                productFrequencyTextBox.Text = productList[productProductLoistview.SelectedIndex].frequency;
                productTypeTextBox.Text = productList[productProductLoistview.SelectedIndex].type;
                productUseTextBox.Text = productList[productProductLoistview.SelectedIndex].use;

                productSkinTypeComboBox.SelectedItem = productList[productProductLoistview.SelectedIndex].skinType;
                consistencyList = RepositoryConsistency.selectConsistency();
                foreach (var o in consistencyList)
                {
                    if (o.id == productList[productProductLoistview.SelectedIndex].id_consistency) {
                        productConsistencyComboBox.SelectedItem = o.ToString();
                    }
                }
                activeList = RepositoryActive.selectActive();
                var activeList2 = RepositoryActive.selectActiveByProduct(productList[productProductLoistview.SelectedIndex]);
                foreach (var o in activeList)
                {
                    productActiveListView.Items.Add(o.ToString());
                }
                foreach (var o2 in activeList2)
                {
                    productActiveListView.SelectedItems.Add(o2.ToString());
                }
            }
        }
        #endregion
    }
}
