﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace Project.Database
{
    /// <summary>
    /// Klasa przetrzymująza dane na temat bazy danych i konfiguracji
    /// </summary>
    class DataBase
    {
        private MySqlConnectionStringBuilder stringBuilder = new MySqlConnectionStringBuilder();

        private static DataBase instance = null;
        public static DataBase Instance
        {
            get
            {
                if (instance == null)
                    instance = new DataBase();
                return instance;
            }
        }

        public MySqlConnection Connection => new MySqlConnection(stringBuilder.ToString());


        private DataBase()
        {   
            //stringBuilder.UserID = Properties.Settings.Default.userID;
            //stringBuilder.Server = Properties.Settings.Default.server;
            //stringBuilder.Database = Properties.Settings.Default.database;
            //stringBuilder.Port = Properties.Settings.Default.port;
            //stringBuilder.Password = Properties.Settings.Default.paswd;

            stringBuilder.UserID = "root";
            stringBuilder.Server = "localhost";
            stringBuilder.Database = "test";
            stringBuilder.Port = 3306;
            stringBuilder.Password = "haslo";
        }
    }
}
