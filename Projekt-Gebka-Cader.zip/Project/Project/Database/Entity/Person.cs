﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Database.Entities
{
    /// <summary>
    /// Klasa służąca do przetrzymywania obiekótw z bazy danych z tabeli Person
    /// </summary>
    class Person
    {
        public sbyte? id { get; set; }
        public string  name { get; set; }
        public string gender { get; set; }
        public sbyte age { get; set; }
        public string skinType { get; set; }
        public Person(string name, string gender, sbyte age, string skintype)
        {
            this.id = null;
            this.name = name;
            this.gender = gender;
            this.age = age;
            this.skinType = skintype;

        }
        public Person(Person pesron)
        {
            this.id = pesron.id;
            this.name = pesron.name;
            this.gender = pesron.gender;
            this.age = pesron.age;
            this.skinType = pesron.skinType;
        }
        public Person(MySqlDataReader rader)
        {
            this.id = sbyte.Parse(rader["id"].ToString());
            this.name = rader["name"].ToString();
            this.gender = rader["gender"].ToString();
            this.age = sbyte.Parse(rader["age"].ToString());
            this.skinType = rader["skin_type"].ToString();
        }
        public override string ToString()
        {
            return $"{this.id} : {this.name} : {this.gender} : {this.age} : {this.skinType}";
        }
        public string ToInsert()
        {
            return $"('{this.name}' , '{this.gender}' , '{this.age}' , '{this.skinType}')";
        }
    }
}
