﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Database.Entities
{
    /// <summary>
    /// Klasa służąca do przetrzymywania obiekótw z bazy danych z tabeli Consistency
    /// </summary>
    class Consistency
    {
        public sbyte? id { get; set; }
        public string consistency { get; set; }
        public Consistency(string consistency)
        {
            this.id = null;
            this.consistency = consistency;

        }
        public Consistency(Consistency consistency)
        {
            this.id = consistency.id;
            this.consistency = consistency.consistency;
        }
        public Consistency(MySqlDataReader rader)
        {
            this.id = sbyte.Parse(rader["id"].ToString());
            this.consistency = rader["consistency"].ToString();
        }
        public override string ToString()
        {
            return $"{this.id} : {this.consistency}";
        }
        public string ToInsert()
        {
            return $"('{this.consistency}')";
        }
    }
}
