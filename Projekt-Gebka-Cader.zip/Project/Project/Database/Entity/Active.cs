﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Database.Entities
{
    /// <summary>
    /// Klasa służąca do przetrzymywania obiekótw z bazy danych z tabeli Active
    /// </summary>
    class Active
    {
        public sbyte? id { get; set; }
        public string substance { get; set; }
        public string substance_use { get; set; }
        public string irritation { get; set; }

        public Active(string substance, string substance_use, string irritation)
        {
            this.id = null;
            this.substance = substance;
            this.substance_use = substance_use;
            this.irritation = irritation;

        }
        public Active(Active active)
        {
            this.id = active.id;
            this.substance = active.substance;
            this.substance_use = active.substance_use;
            this.irritation = active.irritation;
        }
        public Active(MySqlDataReader rader)
        {
            this.id = sbyte.Parse(rader["id"].ToString());
            this.substance = rader["substance"].ToString();
            this.substance_use = rader["substance_use"].ToString();
            this.irritation = rader["irritation"].ToString();
        }
        public override string ToString()
        {
            return $"{this.id} : {this.substance} : {this.substance_use} : {this.irritation}";
        }
        public string ToInsert()
        {
            return $"('{this.substance}' , '{this.substance_use}' , '{this.irritation}')";
        }
    }
}
