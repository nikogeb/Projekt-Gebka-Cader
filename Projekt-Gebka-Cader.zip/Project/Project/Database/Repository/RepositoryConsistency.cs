﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project.Database.Entities;
using MySql.Data.MySqlClient;

namespace Project.Database.Repository
{
    /// <summary>
    /// Statyczna klasa służąca do przeprowadzania operacji na bazie danych tabela Consistency
    /// </summary>
    static class RepositoryConsistency
    {
        public static List<Consistency> selectConsistency()
        {
            List<Consistency> consistency = new List<Consistency>();
            using (var connection = DataBase.Instance.Connection)
            {
                MySqlCommand command = new MySqlCommand("SELECT * FROM consistency", connection);
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                    consistency.Add(new Consistency(reader));
                connection.Close();
            }
            return consistency;
        }
        public static List<Consistency> selectConsistencyByPerson(Person person)
        {
            List<Consistency> consistency = new List<Consistency>();
            using (var connection = DataBase.Instance.Connection)
            {
                MySqlCommand command = new MySqlCommand("SELECT consistency.id, consistency FROM consistency, person_consistency WHERE person_consistency.id_consistency = consistency.id AND person_consistency.id_person=" + person.id, connection);
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                    consistency.Add(new Consistency(reader));
                connection.Close();
            }
            return consistency;
        }
        public static void addConsistency(Consistency consistency)
        {
            using (var connection = DataBase.Instance.Connection)
            {
                MySqlCommand command = new MySqlCommand($"INSERT INTO `consistency`(`consistency`) VALUES {consistency.ToInsert()}", connection);
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
        }
        public static void updateConsistency(Consistency consistency)
        {
             using (var connection = DataBase.Instance.Connection)
             {
                 MySqlCommand command = new MySqlCommand($"UPDATE consistency SET consistency='{consistency.consistency}' WHERE id={consistency.id}", connection);
                 connection.Open();
                 command.ExecuteNonQuery();
                 connection.Close();
             }
        }
    }
}
