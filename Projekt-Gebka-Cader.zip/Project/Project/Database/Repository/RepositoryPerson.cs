﻿using Project.Database.Entities;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Database.Repository
{
    /// <summary>
    /// Statyczna klasa służąca do przeprowadzania operacji na bazie danych tabela Person
    /// </summary>
    static class RepositoryPerson
    {
        public static List<Person> selectPerson()
        {
            List<Person> person = new List<Person>();
            using (var connection = DataBase.Instance.Connection)
            {
                MySqlCommand command = new MySqlCommand("SELECT * FROM person", connection);
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                    person.Add(new Person(reader));
                connection.Close();
            }
            return person;
        }
        public static void addPerson(Person person, List<String> consistency)
        {
            using (var connection = DataBase.Instance.Connection)
            {
                MySqlCommand command = new MySqlCommand($"INSERT INTO `person`(`name` , `gender` , `age` , `skin_type`) VALUES {person.ToInsert()}", connection);
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
            List<Person> persons = RepositoryPerson.selectPerson();
            List<Consistency> consistencyList = RepositoryConsistency.selectConsistency();
            foreach (Consistency conList in consistencyList)
            {
                foreach (string con in consistency)
                {
                    if (con.ToLower() == conList.ToString())
                    {
                        using (var connection = DataBase.Instance.Connection)
                        {
                            MySqlCommand command = new MySqlCommand($"INSERT INTO `Person_consistency`(`id_person` , `id_consistency`) VALUES ({persons[persons.Count - 1].id} , {conList.id})", connection);
                            connection.Open();
                            command.ExecuteNonQuery();
                            connection.Close();
                        }
                    }
                }
            }
        }

        public static void updatePerson(Person person, List<String> consistency)
        {
            using (var connection = DataBase.Instance.Connection)
            {
                MySqlCommand command = new MySqlCommand($"UPDATE person SET name='{person.name}', gender='{person.gender}', age='{person.age}', skin_type='{person.skinType}' WHERE id={person.id}", connection);
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
            List<Consistency> consistencyList = RepositoryConsistency.selectConsistency();
            using (var connection = DataBase.Instance.Connection)
            {
                MySqlCommand command = new MySqlCommand($"DELETE FROM Person_consistency WHERE id_person={person.id}", connection);
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
            foreach (Consistency conList in consistencyList)
            {
                foreach (string con in consistency)
                {
                    if (con.ToLower() == conList.ToString())
                    {
                        using (var connection = DataBase.Instance.Connection)
                        {
                            MySqlCommand command = new MySqlCommand($"INSERT INTO `Person_consistency`(`id_person` , `id_consistency`) VALUES ({person.id} , {conList.id})", connection);
                            connection.Open();
                            command.ExecuteNonQuery();
                            connection.Close();
                        }
                    }
                }
            }
        }
        public static void deletePerson(Person person)
        {
            using (var connection = DataBase.Instance.Connection)
            {
                MySqlCommand command = new MySqlCommand($"DELETE FROM Person_consistency WHERE id_person={person.id}", connection);
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
            using (var connection = DataBase.Instance.Connection)
            {
                MySqlCommand command = new MySqlCommand($"DELETE FROM person WHERE id={person.id}", connection);
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
        }
    }
}