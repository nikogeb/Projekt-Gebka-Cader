﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project.Database.Entities;
using MySql.Data.MySqlClient;

namespace Project.Database.Repository
{
    /// <summary>
    /// Statyczna klasa służąca do przeprowadzania operacji na bazie danych tabela Product
    /// </summary>
    static class ReposityryProduct
    {
        public static List<Product> selectProduct()
        {
            List<Product> product = new List<Product>();
            using (var connection = DataBase.Instance.Connection)
            {
                MySqlCommand command = new MySqlCommand("SELECT * FROM product", connection);
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                    product.Add(new Product(reader));
                connection.Close();
            }
            return product;
        }
        public static List<Product> selectProductByConsistency(Consistency consistency)
        {
            List<Product> product = new List<Product>();
            using (var connection = DataBase.Instance.Connection)
            {
                MySqlCommand command = new MySqlCommand("SELECT product.* FROM product WHERE product.id_consistency = " + consistency.id, connection);
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                    product.Add(new Product(reader));
                connection.Close();
            }
            return product;
        }
        public static void addProcuct(Product product, List<String> active)
        {
            using (var connection = DataBase.Instance.Connection)
            {
                MySqlCommand command = new MySqlCommand($"INSERT INTO `product`(`name` , `type` , `product_use` , `frequency` , `skin_type` , `id_consistency`) VALUES {product.ToInsert()}", connection);
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
            List<Product> products = ReposityryProduct.selectProduct();
            List<Active> activeList = RepositoryActive.selectActive();
            foreach (Active actList in activeList)
            {
                foreach (string act in active)
                {
                    if (act.ToLower() == actList.ToString().ToLower())
                    {
                        using (var connection = DataBase.Instance.Connection)
                        {
                            MySqlCommand command = new MySqlCommand($"INSERT INTO `Product_active`(`id_active` , `id_product`) VALUES ({actList.id} , {products[products.Count - 1].id})", connection);
                            connection.Open();
                            command.ExecuteNonQuery();
                            connection.Close();
                        }
                    }
                }
            }
        }

        public static void updateProcuct(Product product, List<String> active)
        {
            using (var connection = DataBase.Instance.Connection)
            {
                MySqlCommand command = new MySqlCommand($"UPDATE product SET name='{product.name}', type='{product.type}', product_use='{product.use}', frequency='{product.frequency}', skin_type='{product.skinType}', id_consistency={product.id_consistency} WHERE id={product.id}", connection);
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
            using (var connection = DataBase.Instance.Connection)
            {
                MySqlCommand command = new MySqlCommand($"DELETE FROM Product_active WHERE id_product={product.id}", connection);
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
            List<Active> activeList = RepositoryActive.selectActive();
            foreach (Active actList in activeList)
            {
                foreach (string act in active)
                {
                    if (act.ToLower() == actList.ToString().ToLower())
                    {
                        using (var connection = DataBase.Instance.Connection)
                        {
                            MySqlCommand command = new MySqlCommand($"INSERT INTO `Product_active`(`id_active` , `id_product`) VALUES ({actList.id} , {product.id})", connection);
                            connection.Open();
                            command.ExecuteNonQuery();
                            connection.Close();
                        }
                    }
                }
            }
        }
        public static void deleteProcuct(Product product)
        {
            using (var connection = DataBase.Instance.Connection)
            {
                MySqlCommand command = new MySqlCommand($"DELETE FROM Product_active WHERE id_product={product.id}", connection);
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
            using (var connection = DataBase.Instance.Connection)
            {
                MySqlCommand command = new MySqlCommand($"DELETE FROM product WHERE id={product.id}", connection);
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
        }
    }
}
