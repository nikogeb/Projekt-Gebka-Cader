﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project.Database.Entities;
using MySql.Data.MySqlClient;

namespace Project.Database.Repository
{
    /// <summary>
    /// Statyczna klasa służąca do przeprowadzania operacji na bazie danych tabela Active
    /// </summary>
    static class RepositoryActive
    {
        public static List<Active> selectActive()
        {
            List<Active> active = new List<Active>();
            using (var connection = DataBase.Instance.Connection)
            {
                MySqlCommand command = new MySqlCommand("SELECT * FROM active", connection);
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                    active.Add(new Active(reader));
                connection.Close();
            }
            return active;
        }
        public static List<Active> selectActiveByProduct(Product product)
        {
            List<Active> active = new List<Active>();
            using (var connection = DataBase.Instance.Connection)
            {
                MySqlCommand command = new MySqlCommand("SELECT active.* FROM active, product_active WHERE active.id = product_active.id_active AND product_active.id_product =" + product.id, connection);
                connection.Open();
                var reader = command.ExecuteReader();
                while (reader.Read())
                    active.Add(new Active(reader));
                connection.Close();
            }
            return active;
        }

        public static void addActive(Active active)
        {
            using (var connection = DataBase.Instance.Connection)
            {
                MySqlCommand command = new MySqlCommand($"INSERT INTO `active`(`substance` , `substance_use` , `irritation`) VALUES {active.ToInsert()}", connection);
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
        }

        public static void updateActive(Active active)
        {
            using (var connection = DataBase.Instance.Connection)
            {
                MySqlCommand command = new MySqlCommand($"UPDATE active SET irritation='{active.irritation}', substance='{active.substance}', substance_use='{active.substance_use}' WHERE id={active.id}", connection);
                connection.Open();
                command.ExecuteNonQuery();
                connection.Close();
            }
        }
    }
}
